PCF-TreeView — Manual Import Instructions

This archive contains the built PCF control files (bundle and manifest) so you can import the control into a Dataverse solution manually.

Contents of this folder:
- bundle.js (the compiled control bundle)
- ControlManifest.xml (control manifest)
- any other files generated under out/controls/TreeView (icons, resources)

How to import
1. Open Power Apps Maker portal for the target environment:
   https://make.powerapps.com

2. Switch to the target environment (top-right environment selector).

3. Go to Solutions -> Import -> Choose File and select the ZIP file you imported (see below where the zip is placed).

4. Follow the import wizard. After import completes, open the imported solution and click "Publish All Customizations".

5. Add the control to a form or app:
   - Model-driven app / table form:
     * Maker portal -> Tables -> choose the table -> Forms -> open form designer
     * Select the field to attach the control to -> Properties -> Controls tab -> Add Control -> pick your PCF control from the list -> Save & Publish the form.

   - Canvas app:
     * If the control supports Canvas scenarios (manifest authoring required), use Insert -> Custom -> Custom components or the component gallery and bind properties.

Notes and caveats
- This ZIP contains only the built control files (bundle + manifest). Dataverse requires controls to be installed as solution components. The portal import expects a solution ZIP (solution package) with proper metadata. If import fails because the portal expects a solution package, let me know and I can generate a full solution.zip for you.

- If you prefer a ready-to-import solution (recommended), I can prepare a complete solution.zip that the portal will accept directly. That package contains the solution manifest, publisher metadata and the control as a solution component.

- After import, if the control does not appear in the "Add Control" dialog, double-check that the solution import succeeded and that the manifest’s supported properties match the scenario (model-driven vs canvas).

Location of the ZIP produced by the script
- ./out/pcf-treeview-control-files.zip

If you want me to also produce the full solution.zip (recommended for import), say so and I'll create it for you.